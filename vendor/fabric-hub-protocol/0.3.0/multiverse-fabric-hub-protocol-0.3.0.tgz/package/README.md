# Fabric Hub protocol

Private, UNLICENSED shared source for Multiverse registry and sidecar, Locus, and
Multiverse mobile. The CommonJS and ES module bundles include the pinned MIT
Noble primitives; their licenses remain in `THIRD-PARTY-NOTICES.txt`.

`verifyFabricHubManifest(manifest, { trustedRootDids, currentManifestVersion })`
performs JCS canonicalization, strict Ed25519 verification (`zip215: false`),
distinct trusted signer quorum, duplicate system checks, and monotonic version
checks. Roots must come from the caller's existing trusted keyring. No peer hint
or mesh capability establishes trust. Existing surface parsers and their stricter
admission rules remain in their adapters. In particular, sidecar rejects untrusted
declared signers; Locus retains its strict payload parser and rotation checks.

`verifyDidKeySignature`, `verifyCanonicalSignature`, `canonicalizeJcs`,
`sha256Jcs`, and `fabricHubRecordId` share the frozen wire primitives. The root
entry's Hub hashing and verification require no Node crypto, Buffer, TextEncoder, global require, random
source, or network. This package does not sign or hold keys.

Mesh records use one shared set of six types. Dates are serialized ISO strings.
Pool grants and attestations retain the existing `{ payload, signature }` shape.
Owner account IDs are distinct from signing keys; a valid signature alone does
not authorize a pool grant. Runtime consumers must resolve owner/key authority,
current membership, expiry, revocation, nonce replay, and capability at admission.
These types implement no placement, agent, transport, or enrollment behavior.

M3 adds strict structural parsers for `MeshTailnetBinding` and the challenge-bound
current-directory request/response. They reject unknown fields and bounded-shape
violations; they do not establish signature validity, trusted roots, currentness,
WhoIs identity or a placement permit. URL fields use the standard platform URL
implementation. Network callers independently cap raw bytes and reject redirects.
`parseMeshNodeBindingSnapshot` additionally parses an initial M2 record without a
binding for explicit renewal preparation. It preserves the signed bytes and
does not make a historical snapshot current or authorize transport. The transport
authority response still requires both signed bindings.

The separate Node-only `@multiverse/fabric-hub-protocol/keyring` entry reuses
Locus's existing Content Fabric keyring verifier. It has no default root, private
signer, vault, filesystem or Electron dependency. Its legacy canonical serializer
allows nonnegative safe integers and signs objects with `signatures: []`; those
bytes are distinct from Hub JCS. The extraction preserves existing root quorum,
continuity, inclusive validity edges and base64 acceptance. Validation is split
into small helpers while preserving its ordered checks and error strings. A self-signature is
not initial trust: callers first match operator-authorized pins and must retain
and revalidate accepted keyring and manifest floors. The portable root entry
never imports this Node subpath, so mobile does not load it.

Run `npm test --workspace @multiverse/fabric-hub-protocol`. Run
`npm run test:coverage --workspace @multiverse/fabric-hub-protocol` for measured
V8 coverage mapped to the actual TypeScript source. The coverage runner proves
its module matches the shipped CJS bytes except for the source-map link, then
runs the same conformance tests. It labels anonymous V8 functions for the
converter without changing their recorded ranges or counters. Fallow can consume
`--coverage packages/fabric-hub-protocol/coverage/coverage-final.json`; the JSON
and provenance are generated locally. No baselines are expanded.

Run
`npm run pack:artifact --workspace @multiverse/fabric-hub-protocol -- <output-dir>`
to build, produce two independently packed byte-identical archives, and write
source-file and archive SHA-256 provenance. Copy that archive unchanged to the
consumer repositories; never author another verifier there. Packing is local and
does not publish a package. The provenance identifies source bytes even before a
coordinated commit and records its base commit separately.

Version 0.3 combines the bounded reply lifetime, authenticated directory rollback
floor (including rejected members), and verified-reply recovery notification.
`onReplyPosted` reports local `postMessage` completion, not host acknowledgement.
Default pack output is `artifacts/<package-version>/`, preserving the original
0.2.0 tarball and provenance. Consumers must pin the new artifact SHA-256; a
source-only update does not update a vendored consumer. Root/bootstrap and signer
custody remain founder-only prerequisites.

Version 0.2 adds Amendment 1 webUI registration, v2 bidirectional messages, the
browser consumer, and a narrow host-ticket reply signer. Existing v1 fixtures
are packaged byte-identically for compatibility tests only; live channels refuse
v1. `createWebUiDirectoryLoader` reads the current primary registry snapshot at
`GET /systems/:id/webui`, requires deployment-pinned roots and a positive minimum
manifest version, and retains a process high-water version. Update the deployment
minimum whenever the founder publishes a manifest so restart cannot lower it.
Registration verification treats `currentManifestVersion` as that inclusive
minimum; the original manifest admission verifier retains its strictly newer rule.
The fixed host origin is `https://locus.localhost`. Private keys remain in the
caller main/server signer. No auth tokens cross the frame.

The source browser consumer accepts optional `onReplyPosted`, called only after
reply signature/correlation checks, current-registration revalidation and a
successful `postMessage` to the pinned host. Consumers can clear a transient
connection error there. It does not prove that the host received or accepted the
reply. Rejected input, stale/disposed channels and failed posting never trigger
it. Frozen 0.2 artifacts are unchanged; using this callback requires the next
versioned shared artifact.
